<?php
session_start();
include('includes/config.php');
date_default_timezone_set('Asia/Kolkata');
include('includes/checklogin.php');
check_login();
$aid = $_SESSION['id'];

if (isset($_POST['update'])) {
    $regno = $_POST['regno'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $contactno = $_POST['contact'];
    $udate = date('d-m-Y h:i:s', time());

    // Start a transaction
    $mysqli->begin_transaction();

    try {
        // Update userRegistration table
        $query1 = "UPDATE userRegistration SET regNo=?, firstName=?, middleName=?, lastName=?, gender=?, contactNo=?, updationDate=? WHERE id=?";
        $stmt1 = $mysqli->prepare($query1);
        $stmt1->bind_param('sssssisi', $regno, $fname, $mname, $lname, $gender, $contactno, $udate, $aid);
        $stmt1->execute();

        // Update registration table
        $query2 = "UPDATE registration SET regNo=?, firstName=?, middleName=?, lastName=?, gender=?, contactNo=?, updationDate=? WHERE id=?";
        $stmt2 = $mysqli->prepare($query2);
        $stmt2->bind_param('sssssisi', $regno, $fname, $mname, $lname, $gender, $contactno, $udate, $aid);
        $stmt2->execute();

        // Commit the transaction if both queries are successful
        $mysqli->commit();

        echo "<script>alert('Profile updated Successfully');</script>";
    } catch (Exception $e) {
        // Rollback the transaction if an error occurs
        $mysqli->rollback();
        echo "<script>alert('An error occurred: " . $e->getMessage() . "');</script>";
    }
}
?>

<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">
    <title>Profile Updation</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include('includes/header.php'); ?>
    <div class="ts-main-content">
        <?php include('includes/sidebar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">
                <?php
                $ret = "SELECT * FROM userRegistration WHERE id=?";
                $stmt = $mysqli->prepare($ret);
                $stmt->bind_param('i', $aid);
                $stmt->execute();
                $res = $stmt->get_result();
                while ($row = $res->fetch_object()) {
                ?>
                    <div class="row">
                        <div class="col-md-12">
                            <h2 class="page-title"><?php echo $row->firstName; ?>'s Profile</h2>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel panel-primary">
                                        <div class="panel-heading">
                                            Last Updation date: <?php echo $row->updationDate; ?>
                                        </div>
                                        <div class="panel-body">
                                            <form method="post" action="" name="registration" class="form-horizontal">
                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Registration No:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="regno" id="regno" class="form-control" required="required" value="<?php echo $row->regNo; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">First Name:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="fname" id="fname" class="form-control" required="required" value="<?php echo $row->firstName; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Middle Name:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="mname" id="mname" class="form-control" value="<?php echo $row->middleName; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Last Name:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="lname" id="lname" class="form-control" required="required" value="<?php echo $row->lastName; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Gender:</label>
                                                    <div class="col-sm-8">
                                                        <select name="gender" class="form-control" required="required">
                                                            <option value="<?php echo $row->gender; ?>"><?php echo $row->gender; ?></option>
                                                            <option value="male">Male</option>
                                                            <option value="female">Female</option>
                                                            <option value="others">Others</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Contact No:</label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="contact" id="contact" class="form-control" maxlength="10" required="required" value="<?php echo $row->contactNo; ?>">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-2 control-label">Email id:</label>
                                                    <div class="col-sm-8">
                                                        <input type="email" name="email" id="email" class="form-control" readonly value="<?php echo $row->email; ?>">
                                                    </div>
                                                </div>

                                                <div class="col-sm-6 col-sm-offset-4">
                                                    <input type="submit" name="update" Value="Update Profile" class="btn btn-primary">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
